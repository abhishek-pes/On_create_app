package com.example.rupee2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void dol(View v) {
        EditText e1 = (EditText) findViewById(R.id.number1);
        TextView t1 = (TextView) findViewById(R.id.result);
        float rupee = Float.parseFloat(e1.getText().toString());
        float re = rupee / 71.65f;
        t1.setText(Float.toString(re));
    }
}
